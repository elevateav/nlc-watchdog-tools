#!/usr/bin/env python3
"""
watch.py – NLC Network Watchdog
================================
Polls Cisco SG350 / C1300 switches via SSH, detects state changes, and
serves a live correlation dashboard so you can see exactly what the
network was doing when Dante freaked out.

Usage
-----
  python watch.py --site CWY                    # start watching CWY
  python watch.py --site CWY --interval 20      # poll every 20 s
  python watch.py --site CWY --port 8081        # dashboard on 8081
  python watch.py --event "Dante drop stage L"  # mark incident (hits running instance)
  python watch.py --vlan 60                     # focus IGMP monitoring on VLAN 60

Dashboard
---------
  http://localhost:8080

Log file
--------
  ./output/watchdog_<SITE>_<DATE>.jsonl   (JSON-lines, one event per line)
"""

import argparse
import base64
import json
import logging
import os
import re
import sys
import threading
import time
import urllib.request
from collections import deque
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Dict, List, Optional, Set, Tuple
from urllib.parse import urlparse, parse_qs

import yaml

try:
    from netmiko import ConnectHandler, NetmikoTimeoutException, NetmikoAuthenticationException
except ImportError:
    print("ERROR: netmiko not installed.  Run: pip install netmiko")
    sys.exit(1)


# ─────────────────────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────────────────────

VERSION = "1.3.0"
DEFAULT_INTERVAL  = 30          # seconds between polls
DEFAULT_PORT      = 8080        # dashboard HTTP port
DEFAULT_VLAN      = "60"        # Dante VLAN to focus on
MAX_EVENTS        = 500         # in-memory ring buffer size
DISCARD_SPIKE     = 10          # delta that triggers a storm-control alert
UNREACHABLE_MUTE  = 3           # suppress switch_unreachable after this many consecutive failures

SEVERITY_ORDER = {"critical": 0, "warning": 1, "info": 2, "user": 3, "system": 4}

# ─────────────────────────────────────────────────────────────────────────────
# Event helpers
# ─────────────────────────────────────────────────────────────────────────────

def make_event(etype: str, severity: str, detail: str,
               switch: str = "", switch_ip: str = "",
               data: dict = None) -> dict:
    return {
        "ts":        datetime.now().isoformat(timespec="seconds"),
        "type":      etype,
        "severity":  severity,
        "switch":    switch,
        "switch_ip": switch_ip,
        "detail":    detail,
        "data":      data or {},
    }


# ─────────────────────────────────────────────────────────────────────────────
# EventLog  (thread-safe, JSON-lines file + in-memory ring buffer)
# ─────────────────────────────────────────────────────────────────────────────

class EventLog:
    def __init__(self, path: str):
        self._path  = path
        self._buf   = deque(maxlen=MAX_EVENTS)
        self._lock  = threading.Lock()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self._f     = open(path, "a", encoding="utf-8", buffering=1)  # line-buffered
        self.append(make_event("watchdog_start", "system",
                               f"Watchdog started – log: {path}"))

    def append(self, event: dict):
        line = json.dumps(event)
        with self._lock:
            self._buf.append(event)
            self._f.write(line + "\n")

    def recent(self, n: int = 200) -> List[dict]:
        with self._lock:
            events = list(self._buf)
        return list(reversed(events[-n:]))

    def close(self):
        self._f.close()


# ─────────────────────────────────────────────────────────────────────────────
# Cisco SG350 / C1300 output parsers
# ─────────────────────────────────────────────────────────────────────────────

def _strip(text: str) -> str:
    """Remove ANSI escapes and normalise whitespace."""
    text = re.sub(r'\x1b\[[0-9;]*m', '', text)
    return text


def parse_igmp_groups(raw: str) -> Dict[str, Dict[str, Set[str]]]:
    """
    Returns {vlan: {group_ip: {port, ...}}}

    Handles the SG350 / C1300 multi-line IGMPv3 table format:

        VLAN  Group           Type     Version  Port list
          60  239.255.0.1     Dynamic  V3       gi1/0/25
                                                gi1/0/26
                                                Forbidden ports:
                                                gi1/0/27
        Source List:
            (S,G) 10.1.60.x  ...

    Rules:
      - A row is only a real data row if it starts with a VLAN number followed
        by a complete dotted-quad group IP (all 4 octets present).
      - Port columns must look like gi/te/fa<u>/<s>/<p> to be accepted.
      - Lines starting with "Forbidden", "Source", digits-only, or containing
        no slash-separated port format are ignored.
    """
    # Regex for a valid port name: gi1/0/25, te1/0/1, fa0/0/1 etc.
    PORT_RE = re.compile(r'^(?:gi|te|fa)\d+/\d+/\d+$', re.I)
    # Regex for a full IPv4 address (all 4 octets)
    IP_RE   = re.compile(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$')

    result: Dict[str, Dict[str, Set[str]]] = {}
    current_vlan  = None
    current_group = None

    for line in raw.splitlines():
        stripped = line.strip()

        # Skip header, separator, and noise lines
        if not stripped:
            continue
        low = stripped.lower()
        if low.startswith(('vlan', '----', 'source', 'forbidden', '(s,g)')):
            continue

        # --- Data row: starts with a VLAN number ---
        row_m = re.match(
            r'^(\d+)\s+([\d.]+)\s+\S+\s+[Vv]?\S*\s*(.*)?$', stripped
        )
        if row_m:
            vlan_candidate  = row_m.group(1)
            group_candidate = row_m.group(2)
            rest            = (row_m.group(3) or "").strip()

            # Only accept rows where the group is a complete dotted-quad
            if not IP_RE.match(group_candidate):
                continue

            current_vlan  = vlan_candidate
            current_group = group_candidate
            result.setdefault(current_vlan, {}).setdefault(current_group, set())

            # Parse any ports on the same line
            for token in re.split(r'[,\s]+', rest):
                token = token.strip().lower()
                if PORT_RE.match(token):
                    result[current_vlan][current_group].add(token)
            continue

        # --- Continuation line: additional ports for the current group ---
        if current_vlan and current_group:
            for token in re.split(r'[,\s]+', stripped):
                token = token.strip().lower()
                if PORT_RE.match(token):
                    result[current_vlan][current_group].add(token)

    return result


def parse_querier(raw: str) -> Dict[str, dict]:
    """
    Returns {vlan: {status, ip, version}}
    """
    result = {}
    for line in raw.splitlines():
        line = line.strip()
        # e.g.: 60  Active  10.1.60.20  V2  00:00:29
        m = re.match(
            r'^(\d+)\s+(Active|Passive|Disabled|Non-Querier)\s+([\d.]+)\s+[Vv]?(\d+)',
            line, re.I
        )
        if m:
            result[m.group(1)] = {
                "status":  m.group(2).lower(),
                "ip":      m.group(3),
                "version": m.group(4),
            }
    return result


def parse_interface_status(raw: str) -> Dict[str, str]:
    """
    Returns {port: "up"|"down"|"err-disabled"}
    """
    result = {}
    for line in raw.splitlines():
        line = line.strip()
        # gi1/0/1  1G-Copper  Auto  Auto  ...  Up  ...
        m = re.match(r'^((?:gi|te|fa)\d+/\d+/\d+)\s+.*?(Up|Down|Err-Disabled)', line, re.I)
        if m:
            result[m.group(1).lower()] = m.group(2).lower()
    return result


def parse_counters(raw: str) -> Dict[str, Dict[str, int]]:
    """
    Returns {port: {in_discard, out_discard, in_errors, out_errors}}
    Handles 'show interfaces counters' bulk output on SG350.
    """
    result: Dict[str, Dict[str, int]] = {}
    current_port = None

    for line in raw.splitlines():
        line = line.strip()

        # Port header line:  "Counters for GigabitEthernet1/0/25:" or "gi1/0/25  ..."
        pm = re.match(r'(?:Counters for\s+)?(?:GigabitEthernet|TenGigabitEthernet|gi|te)(\d+/\d+/\d+)', line, re.I)
        if pm:
            raw_port = pm.group(1)
            current_port = f"gi{raw_port}"
            result.setdefault(current_port, {"in_discard":0,"out_discard":0,"in_errors":0,"out_errors":0})
            continue

        if current_port:
            for key, pattern in [
                ("in_discard",  r'InDiscard\s*:\s*(\d+)'),
                ("out_discard", r'OutDiscard\s*:\s*(\d+)'),
                ("in_errors",   r'InErrors\s*:\s*(\d+)'),
                ("out_errors",  r'OutErrors\s*:\s*(\d+)'),
            ]:
                m = re.search(pattern, line, re.I)
                if m:
                    result[current_port][key] = int(m.group(1))

        # Also handle single-line tabular format:
        # gi1/0/1  0  0  0  0  0  0  0  0  0  0
        tab = re.match(
            r'^((?:gi|te)\d+/\d+/\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)',
            line, re.I
        )
        if tab:
            port = tab.group(1).lower()
            result[port] = {
                "in_discard":  int(tab.group(5)),
                "out_discard": int(tab.group(6)),
                "in_errors":   int(tab.group(3)),
                "out_errors":  int(tab.group(7)),
            }

    return result


def parse_stp_changes(raw: str) -> Dict[str, int]:
    """
    Returns {vlan: topology_change_count}
    Looks for lines like: 'Number of topology changes 5'
    """
    result: Dict[str, int] = {}
    current_vlan = None
    for line in raw.splitlines():
        vm = re.search(r'spanning[- ]tree\s+(?:mode\s+)?(?:vlan\s+)?(\d+)', line, re.I)
        if vm:
            current_vlan = vm.group(1)
        cm = re.search(r'[Nn]umber of topology changes\s+(\d+)', line)
        if cm and current_vlan:
            result[current_vlan] = int(cm.group(1))
    return result


# ─────────────────────────────────────────────────────────────────────────────
# SwitchPoller  (one instance per switch)
# ─────────────────────────────────────────────────────────────────────────────

class SwitchPoller:
    """Manages SSH to one switch and tracks state deltas between polls."""

    def __init__(self, switch_cfg: dict, watch_vlan: str = DEFAULT_VLAN):
        self.cfg        = switch_cfg
        self.ip         = switch_cfg["ip"]
        self.hostname   = switch_cfg.get("hostname", self.ip)
        self.vlan       = watch_vlan
        self._conn           = None
        self._lock           = threading.Lock()
        self._state: dict    = {}   # last known state snapshot
        self.connected       = False
        self.last_poll       = None
        self.last_error      = None
        self._fail_count     = 0    # consecutive unreachable polls
        self._log = logging.getLogger(f"nlc.watch.{self.ip}")

    # ── Connection management ─────────────────────────────────────────────

    def connect(self) -> bool:
        try:
            params = {
                "device_type": self.cfg.get("device_type", "cisco_s300"),
                "host":        self.ip,
                "port":        int(self.cfg.get("port", 22)),
                "username":    self.cfg["username"],
                "password":    self.cfg["password"],
                "timeout":     20,
                "auth_timeout":20,
                "fast_cli":    False,
            }
            secret = self.cfg.get("secret", "")
            if secret:
                params["secret"] = secret
            self._conn = ConnectHandler(**params)
            if secret:
                try:
                    self._conn.enable()
                except Exception:
                    pass
            self.connected  = True
            self.last_error = None
            self._log.info(f"Connected to {self.hostname} ({self.ip})")
            return True
        except (NetmikoTimeoutException, NetmikoAuthenticationException) as e:
            self.last_error = str(e)
            self.connected  = False
            return False
        except Exception as e:
            self.last_error = str(e)
            self.connected  = False
            return False

    def disconnect(self):
        try:
            if self._conn:
                self._conn.disconnect()
        except Exception:
            pass
        self.connected = False
        self._conn = None

    def _cmd(self, command: str, timeout: int = 30) -> Optional[str]:
        """Run a command; returns None on failure."""
        try:
            return _strip(self._conn.send_command(command, read_timeout=timeout))
        except Exception as e:
            self._log.warning(f"Command failed '{command}': {e}")
            return None

    # ── Poll  ─────────────────────────────────────────────────────────────

    def poll(self) -> List[dict]:
        """
        SSH into the switch, collect current state, diff against previous,
        return a list of Event dicts for anything that changed.
        """
        events: List[dict] = []

        with self._lock:
            if not self.connected:
                if not self.connect():
                    self._fail_count += 1
                    # Log every failure for first UNREACHABLE_MUTE attempts,
                    # then only log every 10th to avoid spamming the log with
                    # devices that are permanently unreachable (e.g. non-SSH nodes
                    # that ended up in the graph_state from CDP discovery).
                    if self._fail_count <= UNREACHABLE_MUTE or self._fail_count % 10 == 0:
                        note = "" if self._fail_count <= UNREACHABLE_MUTE else \
                            f" (suppressed — failure #{self._fail_count})"
                        events.append(make_event(
                            "switch_unreachable", "critical",
                            f"Cannot reach {self.hostname} ({self.ip}){note}: {self.last_error}",
                            switch=self.hostname, switch_ip=self.ip,
                            data={"fail_count": self._fail_count},
                        ))
                    return events
                else:
                    self._fail_count = 0
                    events.append(make_event(
                        "switch_connected", "system",
                        f"Connected to {self.hostname} ({self.ip})",
                        switch=self.hostname, switch_ip=self.ip,
                    ))

            try:
                events += self._do_poll()
                self.last_poll = datetime.now().isoformat(timespec="seconds")
            except Exception as e:
                self._log.error(f"Poll failed for {self.ip}: {e}")
                self.disconnect()
                events.append(make_event(
                    "poll_error", "warning",
                    f"{self.hostname}: poll error – {e}",
                    switch=self.hostname, switch_ip=self.ip,
                ))

        return events

    def _do_poll(self) -> List[dict]:
        events: List[dict] = []
        new_state: dict = {}

        # ── IGMP groups ───────────────────────────────────────────────────
        raw = self._cmd("show ip igmp snooping groups")
        if raw is not None:
            new_state["igmp_groups"] = parse_igmp_groups(raw)
            events += self._diff_igmp(new_state["igmp_groups"])

        # ── Querier status ────────────────────────────────────────────────
        raw = self._cmd("show ip igmp snooping querier")
        if raw is not None:
            new_state["querier"] = parse_querier(raw)
            events += self._diff_querier(new_state["querier"])

        # ── Interface link states ─────────────────────────────────────────
        raw = self._cmd("show interfaces status")
        if raw is not None:
            new_state["interfaces"] = parse_interface_status(raw)
            events += self._diff_interfaces(new_state["interfaces"])

        # ── Interface discard/error counters ─────────────────────────────
        raw = self._cmd("show interfaces counters")
        if raw is not None:
            new_state["counters"] = parse_counters(raw)
            events += self._diff_counters(new_state["counters"])

        # ── STP topology changes ──────────────────────────────────────────
        raw = self._cmd("show spanning-tree")
        if raw is not None:
            new_state["stp_changes"] = parse_stp_changes(raw)
            events += self._diff_stp(new_state["stp_changes"])

        # Update stored state
        self._state = new_state
        return events

    # ── Diff helpers ──────────────────────────────────────────────────────

    def _diff_igmp(self, new: Dict) -> List[dict]:
        events = []
        old = self._state.get("igmp_groups", {})

        # Check VLAN of interest first, then all other VLANs
        all_vlans = set(old.keys()) | set(new.keys())
        focus_vlans = sorted(all_vlans, key=lambda v: (v != self.vlan, v))

        for vlan in focus_vlans:
            old_groups = old.get(vlan, {})
            new_groups = new.get(vlan, {})

            # Groups that disappeared entirely
            for group in set(old_groups) - set(new_groups):
                events.append(make_event(
                    "igmp_leave", "warning",
                    f"{self.hostname}  VLAN {vlan}  group {group} — ALL members left",
                    switch=self.hostname, switch_ip=self.ip,
                    data={"vlan": vlan, "group": group,
                          "old_ports": list(old_groups[group])},
                ))

            # Groups that appeared
            for group in set(new_groups) - set(old_groups):
                if not self._state:  # first poll — don't flood with joins
                    continue
                events.append(make_event(
                    "igmp_join", "info",
                    f"{self.hostname}  VLAN {vlan}  group {group} — new join "
                    f"({', '.join(sorted(new_groups[group]))})",
                    switch=self.hostname, switch_ip=self.ip,
                    data={"vlan": vlan, "group": group,
                          "ports": list(new_groups[group])},
                ))

            # Existing groups with port changes
            for group in set(old_groups) & set(new_groups):
                old_ports = old_groups[group]
                new_ports = new_groups[group]
                left  = old_ports - new_ports
                joined = new_ports - old_ports
                if left:
                    events.append(make_event(
                        "igmp_leave", "warning",
                        f"{self.hostname}  VLAN {vlan}  group {group}  "
                        f"port(s) left: {', '.join(sorted(left))}",
                        switch=self.hostname, switch_ip=self.ip,
                        data={"vlan": vlan, "group": group,
                              "left": list(left), "remaining": list(new_ports)},
                    ))
                if joined and self._state:
                    events.append(make_event(
                        "igmp_join", "info",
                        f"{self.hostname}  VLAN {vlan}  group {group}  "
                        f"port(s) joined: {', '.join(sorted(joined))}",
                        switch=self.hostname, switch_ip=self.ip,
                        data={"vlan": vlan, "group": group,
                              "joined": list(joined), "all_ports": list(new_ports)},
                    ))

        return events

    def _diff_querier(self, new: Dict) -> List[dict]:
        events = []
        old = self._state.get("querier", {})
        for vlan, info in new.items():
            old_info = old.get(vlan, {})
            if not old_info and not self._state:
                # First poll — just note active status
                if info.get("status") == "active":
                    events.append(make_event(
                        "querier_active", "info",
                        f"{self.hostname}  VLAN {vlan}  querier active "
                        f"({info['ip']}  v{info['version']})",
                        switch=self.hostname, switch_ip=self.ip,
                        data={"vlan": vlan, **info},
                    ))
                continue

            old_status = old_info.get("status", "")
            new_status = info.get("status", "")

            if old_status == "active" and new_status != "active":
                events.append(make_event(
                    "querier_lost", "critical",
                    f"{self.hostname}  VLAN {vlan}  QUERIER WENT {new_status.upper()} "
                    f"(was {old_info.get('ip', '?')})",
                    switch=self.hostname, switch_ip=self.ip,
                    data={"vlan": vlan, "old": old_info, "new": info},
                ))
            elif old_status != "active" and new_status == "active":
                events.append(make_event(
                    "querier_active", "info",
                    f"{self.hostname}  VLAN {vlan}  querier now active ({info['ip']})",
                    switch=self.hostname, switch_ip=self.ip,
                    data={"vlan": vlan, **info},
                ))
            elif old_info.get("ip") != info.get("ip") and info.get("ip"):
                events.append(make_event(
                    "querier_change", "warning",
                    f"{self.hostname}  VLAN {vlan}  querier IP changed "
                    f"{old_info.get('ip')} → {info['ip']}  (election happened?)",
                    switch=self.hostname, switch_ip=self.ip,
                    data={"vlan": vlan, "old_ip": old_info.get("ip"), "new_ip": info["ip"]},
                ))

        # VLANs that had a querier and now have none
        for vlan in set(old) - set(new):
            if old[vlan].get("status") == "active":
                events.append(make_event(
                    "querier_lost", "critical",
                    f"{self.hostname}  VLAN {vlan}  querier disappeared entirely",
                    switch=self.hostname, switch_ip=self.ip,
                    data={"vlan": vlan, "was": old[vlan]},
                ))

        return events

    def _diff_interfaces(self, new: Dict) -> List[dict]:
        events = []
        old = self._state.get("interfaces", {})
        if not self._state:
            return events  # don't fire on first poll
        for port, state in new.items():
            old_state = old.get(port)
            if old_state and old_state != state:
                sev = "critical" if state in ("down", "err-disabled") else "info"
                events.append(make_event(
                    "link_down" if state != "up" else "link_up",
                    sev,
                    f"{self.hostname}  {port}  link {old_state} → {state}",
                    switch=self.hostname, switch_ip=self.ip,
                    data={"port": port, "old": old_state, "new": state},
                ))
        return events

    def _diff_counters(self, new: Dict) -> List[dict]:
        events = []
        old = self._state.get("counters", {})
        if not self._state:
            return events
        for port, cnts in new.items():
            old_cnts = old.get(port, {})
            for key, label, sev in [
                ("out_discard", "OutDiscard (storm-control?)", "critical"),
                ("in_discard",  "InDiscard",                   "warning"),
                ("in_errors",   "InErrors (CRC/frame)",        "warning"),
                ("out_errors",  "OutErrors",                   "warning"),
            ]:
                old_val = old_cnts.get(key, 0)
                new_val = cnts.get(key, 0)
                delta   = new_val - old_val
                if delta >= DISCARD_SPIKE:
                    events.append(make_event(
                        "counter_spike", sev,
                        f"{self.hostname}  {port}  {label} +{delta} "
                        f"(total {new_val})",
                        switch=self.hostname, switch_ip=self.ip,
                        data={"port": port, "counter": key,
                              "delta": delta, "total": new_val},
                    ))
        return events

    def _diff_stp(self, new: Dict) -> List[dict]:
        events = []
        old = self._state.get("stp_changes", {})
        if not self._state:
            return events
        for vlan, count in new.items():
            old_count = old.get(vlan, count)  # baseline on first seen
            if count > old_count:
                delta = count - old_count
                events.append(make_event(
                    "stp_change", "warning",
                    f"{self.hostname}  VLAN {vlan}  STP topology change "
                    f"(+{delta} TCN, total {count})",
                    switch=self.hostname, switch_ip=self.ip,
                    data={"vlan": vlan, "delta": delta, "total": count},
                ))
        return events

    def current_state_summary(self) -> dict:
        """Return a JSON-safe snapshot for the dashboard."""
        return {
            "hostname":   self.hostname,
            "ip":         self.ip,
            "connected":  self.connected,
            "last_poll":  self.last_poll,
            "last_error": self.last_error,
            "igmp_groups": {
                vlan: {grp: sorted(ports) for grp, ports in groups.items()}
                for vlan, groups in self._state.get("igmp_groups", {}).items()
            },
            "querier":    self._state.get("querier", {}),
            "interfaces": {
                k: v for k, v in self._state.get("interfaces", {}).items()
                if v != "up"   # only show non-up ports in the summary
            },
        }


# ─────────────────────────────────────────────────────────────────────────────
# WatchdogEngine
# ─────────────────────────────────────────────────────────────────────────────

class WatchdogEngine:
    def __init__(self, pollers: List[SwitchPoller], log: EventLog, interval: int):
        self._pollers  = pollers
        self._log      = log
        self._interval = interval
        self._running  = False
        self._paused   = False

    def start(self):
        self._running = True
        self._paused  = False
        t = threading.Thread(target=self._loop, daemon=True, name="watchdog")
        t.start()

    def stop(self):
        self._running = False

    def pause(self):
        self._paused = True
        logging.info("Watchdog polling PAUSED")

    def resume(self):
        self._paused = False
        logging.info("Watchdog polling RESUMED")

    @property
    def is_paused(self) -> bool:
        return self._paused

    def _loop(self):
        # Stagger initial polls so we don't hit all switches simultaneously
        for i, poller in enumerate(self._pollers):
            time.sleep(i * 2)
            if not self._paused:
                threading.Thread(
                    target=self._poll_one,
                    args=(poller,),
                    daemon=True,
                    name=f"poll-{poller.ip}",
                ).start()

        # Recurring polls
        while self._running:
            time.sleep(self._interval)
            if self._paused:
                continue
            for poller in self._pollers:
                threading.Thread(
                    target=self._poll_one,
                    args=(poller,),
                    daemon=True,
                    name=f"poll-{poller.ip}",
                ).start()

    def _poll_one(self, poller: SwitchPoller):
        events = poller.poll()
        for ev in events:
            self._log.append(ev)
            level = ev.get("severity", "info")
            msg   = f"[{ev['type'].upper()}] {ev['detail']}"
            if level == "critical":
                logging.critical(msg)
            elif level == "warning":
                logging.warning(msg)
            else:
                logging.info(msg)

    def state_summary(self) -> List[dict]:
        return [p.current_state_summary() for p in self._pollers]


# ─────────────────────────────────────────────────────────────────────────────
# GitHub log upload
# ─────────────────────────────────────────────────────────────────────────────

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
GITHUB_CFG_FILE = os.path.join(_SCRIPT_DIR, "github_config.json")
WATCHDOG_LOG_REPO = "nlc-watchdog-logs"

def load_github_config() -> Optional[dict]:
    """Load GitHub token + owner from github_config.json (same dir as watch.py)."""
    if not os.path.exists(GITHUB_CFG_FILE):
        return None
    try:
        with open(GITHUB_CFG_FILE, encoding="utf-8") as f:
            cfg = json.load(f)
        if cfg.get("token") and cfg.get("repo_owner"):
            return cfg
    except Exception:
        pass
    return None


def upload_log_to_github(log_path: str, site_name: str,
                         github_cfg: dict) -> Tuple[bool, str]:
    """
    Upload a JSONL log file to the private nlc-watchdog-logs repo.
    Returns (success: bool, message: str).
    """
    if not os.path.exists(log_path):
        return False, f"Log file not found: {log_path}"

    token = github_cfg.get("token", "")
    owner = github_cfg.get("repo_owner", "")
    repo  = WATCHDOG_LOG_REPO

    if not token or not owner:
        return False, "GitHub token or owner not configured in github_config.json"

    filename = os.path.basename(log_path)
    remote_path = f"{site_name}/{filename}"
    api_url = f"https://api.github.com/repos/{owner}/{repo}/contents/{remote_path}"

    # Read + base64-encode the log
    try:
        with open(log_path, "rb") as f:
            content_b64 = base64.b64encode(f.read()).decode("utf-8")
    except Exception as e:
        return False, f"Could not read log: {e}"

    # Check if file already exists (need SHA to update)
    sha = None
    try:
        req = urllib.request.Request(
            api_url,
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
            },
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            existing = json.loads(resp.read())
            sha = existing.get("sha")
    except urllib.error.HTTPError as e:
        if e.code != 404:
            return False, f"GitHub API error checking file: {e.code}"
    except Exception as e:
        return False, f"GitHub connection error: {e}"

    # PUT the file
    payload: dict = {
        "message": f"watchdog log {site_name} {filename}",
        "content": content_b64,
    }
    if sha:
        payload["sha"] = sha

    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            api_url,
            data=data,
            method="PUT",
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/vnd.github+json",
                "Content-Type": "application/json",
                "X-GitHub-Api-Version": "2022-11-28",
            },
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read())
            html_url = result.get("content", {}).get("html_url", "")
            return True, f"Uploaded: {html_url or remote_path}"
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        return False, f"GitHub upload failed ({e.code}): {body[:200]}"
    except Exception as e:
        return False, f"Upload error: {e}"


# ─────────────────────────────────────────────────────────────────────────────
# Dashboard  (embedded HTML + simple HTTP API)
# ─────────────────────────────────────────────────────────────────────────────

DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>NLC Network Watchdog</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  :root {
    --bg:       #0d1117;
    --panel:    #161b22;
    --border:   #30363d;
    --text:     #e6edf3;
    --muted:    #7d8590;
    --red:      #f85149;
    --orange:   #d29922;
    --blue:     #58a6ff;
    --green:    #3fb950;
    --purple:   #bc8cff;
    --grey:     #484f58;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: var(--bg); color: var(--text); font-family: 'SF Mono', 'Fira Code', monospace; font-size: 13px; }

  /* ── Top bar ── */
  header {
    display: flex; align-items: center; gap: 12px;
    padding: 10px 16px; background: var(--panel); border-bottom: 1px solid var(--border);
    position: sticky; top: 0; z-index: 100;
  }
  .site-name { font-size: 15px; font-weight: 700; color: var(--text); }
  .poll-dot {
    width: 10px; height: 10px; border-radius: 50%; background: var(--grey);
    transition: background 0.3s;
  }
  .poll-dot.ok     { background: var(--green); }
  .poll-dot.error  { background: var(--red); }
  .last-poll       { color: var(--muted); font-size: 11px; }
  .spacer          { flex: 1; }
  .mark-wrap       { display: flex; gap: 6px; align-items: center; }
  #mark-input {
    background: var(--bg); border: 1px solid var(--border); color: var(--text);
    padding: 5px 10px; border-radius: 4px; font-family: inherit; font-size: 12px;
    width: 260px; outline: none;
  }
  #mark-input:focus { border-color: var(--purple); }
  #mark-btn {
    background: var(--purple); color: #fff; border: none;
    padding: 5px 14px; border-radius: 4px; cursor: pointer;
    font-family: inherit; font-size: 12px; font-weight: 600;
  }
  #mark-btn:hover { filter: brightness(1.2); }
  .kbd { color: var(--muted); font-size: 10px; }

  /* ── Control buttons ── */
  .ctrl-btn {
    border: none; padding: 5px 12px; border-radius: 4px; cursor: pointer;
    font-family: inherit; font-size: 12px; font-weight: 600;
  }
  #pause-btn  { background: var(--orange); color: #000; }
  #resume-btn { background: var(--green);  color: #000; display: none; }
  #upload-btn { background: var(--blue);   color: #000; }
  .ctrl-btn:hover { filter: brightness(1.15); }
  .ctrl-btn:disabled { opacity: 0.5; cursor: default; }
  #upload-status { font-size: 11px; color: var(--muted); max-width: 240px;
                   overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

  /* ── Layout ── */
  .layout { display: flex; height: calc(100vh - 45px); overflow: hidden; }
  .feed-col {
    flex: 1; overflow-y: auto; padding: 10px 12px;
    border-right: 1px solid var(--border);
  }
  .state-col { width: 320px; overflow-y: auto; padding: 10px 12px; }

  /* ── Events ── */
  .event {
    display: flex; gap: 8px; align-items: flex-start;
    padding: 5px 8px; border-radius: 4px; margin-bottom: 3px;
    border-left: 3px solid transparent;
    animation: fadein 0.3s ease;
  }
  @keyframes fadein { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; } }

  .ev-critical { border-color: var(--red);    background: rgba(248,81,73,0.08); }
  .ev-warning  { border-color: var(--orange); background: rgba(210,153,34,0.08); }
  .ev-info     { border-color: var(--blue);   background: rgba(88,166,255,0.06); }
  .ev-user     { border-color: var(--purple); background: rgba(188,140,255,0.12); }
  .ev-system   { border-color: var(--grey);   background: transparent; }

  .ev-ts   { color: var(--muted); white-space: nowrap; font-size: 11px; padding-top: 1px; }
  .ev-type {
    font-size: 10px; font-weight: 700; text-transform: uppercase;
    white-space: nowrap; padding: 1px 5px; border-radius: 3px;
    background: var(--border);
  }
  .ev-critical .ev-type { color: var(--red); }
  .ev-warning  .ev-type { color: var(--orange); }
  .ev-info     .ev-type { color: var(--blue); }
  .ev-user     .ev-type { color: var(--purple); }
  .ev-system   .ev-type { color: var(--grey); }

  .ev-detail   { color: var(--text); flex: 1; line-height: 1.5; }
  .ev-switch   { color: var(--muted); font-size: 11px; }

  /* ── State panel ── */
  .card {
    background: var(--panel); border: 1px solid var(--border);
    border-radius: 6px; padding: 10px 12px; margin-bottom: 10px;
  }
  .card-title   { font-size: 11px; font-weight: 700; color: var(--muted);
                  text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 8px; }
  .card-host    { font-size: 13px; font-weight: 700; color: var(--text); }
  .card-ip      { font-size: 11px; color: var(--muted); }
  .status-dot   { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 6px; }
  .dot-ok       { background: var(--green); }
  .dot-err      { background: var(--red); }

  .group-list   { margin-top: 6px; }
  .group-row    { display: flex; justify-content: space-between; padding: 2px 0;
                  border-bottom: 1px solid var(--border); font-size: 11px; }
  .group-ip     { color: var(--blue); }
  .group-ports  { color: var(--muted); max-width: 150px; text-align: right;
                  overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

  .querier-row  { font-size: 11px; margin-top: 4px; }
  .q-active     { color: var(--green); }
  .q-inactive   { color: var(--red); }

  .down-ports   { margin-top: 6px; font-size: 11px; color: var(--orange); }

  .section-hdr  { font-size: 10px; font-weight: 700; color: var(--muted);
                  text-transform: uppercase; margin: 8px 0 4px; }

  #empty-feed   { color: var(--muted); text-align: center; padding: 40px; font-size: 12px; }

  .flash { animation: flash 0.8s ease; }
  @keyframes flash { 0%,100% { background: inherit; } 50% { background: rgba(188,140,255,0.25); } }
</style>
</head>
<body>

<header>
  <div class="poll-dot" id="poll-dot"></div>
  <div class="site-name" id="site-name">NLC Watchdog</div>
  <div class="last-poll" id="last-poll">connecting…</div>
  <div class="spacer"></div>
  <button id="pause-btn"  class="ctrl-btn" onclick="pausePolling()">⏸ PAUSE</button>
  <button id="resume-btn" class="ctrl-btn" onclick="resumePolling()">▶ RESUME</button>
  <button id="upload-btn" class="ctrl-btn" onclick="uploadLogs()">☁ SEND LOGS</button>
  <span id="upload-status"></span>
  <div class="mark-wrap">
    <input id="mark-input" placeholder="Describe the incident… (M to focus)" maxlength="120">
    <button id="mark-btn" onclick="markEvent()">🔴 MARK EVENT</button>
  </div>
  <span class="kbd">⌨ M</span>
</header>

<div class="layout">
  <div class="feed-col" id="feed">
    <div id="empty-feed">Waiting for events…</div>
  </div>
  <div class="state-col" id="state-panel"></div>
</div>

<script>
let lastTs = null;

function sev(e) { return e.severity || 'info'; }

function renderEvent(e) {
  const cls = 'ev-' + sev(e);
  const ts  = e.ts ? e.ts.replace('T',' ') : '';
  const sw  = e.switch ? `<span class="ev-switch">[${e.switch}]</span> ` : '';
  return `<div class="event ${cls}">
    <span class="ev-ts">${ts}</span>
    <span class="ev-type">${e.type || ''}</span>
    <span class="ev-detail">${sw}${e.detail || ''}</span>
  </div>`;
}

function refreshFeed() {
  fetch('/api/events')
    .then(r => r.json())
    .then(data => {
      const feed = document.getElementById('feed');
      const empty = document.getElementById('empty-feed');
      if (!data.length) return;
      if (empty) empty.remove();

      // Only prepend new events
      const newEvents = lastTs
        ? data.filter(e => e.ts > lastTs)
        : data;

      if (newEvents.length) {
        lastTs = data[0].ts;
        const frag = newEvents.map(renderEvent).join('');
        feed.insertAdjacentHTML('afterbegin', frag);
        document.getElementById('poll-dot').className = 'poll-dot ok';
        document.getElementById('last-poll').textContent =
          'last event ' + (lastTs || '').replace('T',' ');
      }
    })
    .catch(() => {
      document.getElementById('poll-dot').className = 'poll-dot error';
    });
}

function refreshState() {
  fetch('/api/state')
    .then(r => r.json())
    .then(switches => {
      const panel = document.getElementById('state-panel');
      const siteName = document.getElementById('site-name');
      if (!switches.length) return;

      panel.innerHTML = switches.map(sw => {
        const dotCls = sw.connected ? 'dot-ok' : 'dot-err';
        const pollTs = sw.last_poll ? sw.last_poll.replace('T',' ') : 'never';

        // IGMP groups by VLAN
        let groupsHtml = '';
        const groups = sw.igmp_groups || {};
        const vlans  = Object.keys(groups).sort();
        if (vlans.length) {
          groupsHtml = vlans.map(vlan => {
            const grpMap = groups[vlan];
            const rows = Object.entries(grpMap).map(([grp, ports]) =>
              `<div class="group-row">
                <span class="group-ip">${grp}</span>
                <span class="group-ports">${ports.join(', ')}</span>
              </div>`
            ).join('');
            return `<div class="section-hdr">IGMP VLAN ${vlan}</div>
                    <div class="group-list">${rows || '<span style="color:var(--muted);font-size:11px">no dynamic groups</span>'}</div>`;
          }).join('');
        }

        // Querier
        let querierHtml = '';
        const querier = sw.querier || {};
        if (Object.keys(querier).length) {
          querierHtml = '<div class="section-hdr">QUERIER</div>' +
            Object.entries(querier).map(([vlan, q]) => {
              const cls = q.status === 'active' ? 'q-active' : 'q-inactive';
              return `<div class="querier-row">VLAN ${vlan}: <span class="${cls}">${q.status}</span> ${q.ip} v${q.version}</div>`;
            }).join('');
        }

        // Down ports
        let downHtml = '';
        const ifaces = sw.interfaces || {};
        const downPorts = Object.entries(ifaces).filter(([,s]) => s !== 'up');
        if (downPorts.length) {
          downHtml = '<div class="section-hdr">NON-UP PORTS</div>' +
            '<div class="down-ports">' +
            downPorts.map(([p,s]) => `${p}: ${s}`).join('<br>') +
            '</div>';
        }

        return `<div class="card">
          <div class="card-title">SWITCH</div>
          <div><span class="status-dot ${dotCls}"></span>
               <span class="card-host">${sw.hostname}</span>
               <span class="card-ip"> ${sw.ip}</span></div>
          <div style="font-size:10px;color:var(--muted);margin-top:2px">polled ${pollTs}</div>
          ${groupsHtml}${querierHtml}${downHtml}
          ${sw.last_error ? `<div style="color:var(--red);font-size:11px;margin-top:6px">⚠ ${sw.last_error}</div>` : ''}
        </div>`;
      }).join('');
    });
}

function markEvent() {
  const input = document.getElementById('mark-input');
  const text  = input.value.trim();
  if (!text) { input.focus(); return; }
  fetch('/api/event', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({note: text}),
  }).then(() => {
    input.value = '';
    input.classList.add('flash');
    setTimeout(() => input.classList.remove('flash'), 800);
    refreshFeed();
  });
}

function pausePolling() {
  fetch('/api/control', {method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({action:'pause'})})
  .then(r => r.json()).then(d => {
    if (d.ok) {
      document.getElementById('pause-btn').style.display  = 'none';
      document.getElementById('resume-btn').style.display = '';
      document.getElementById('last-poll').textContent = '⏸ polling paused';
      document.getElementById('poll-dot').className = 'poll-dot';
    }
  });
}

function resumePolling() {
  fetch('/api/control', {method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({action:'resume'})})
  .then(r => r.json()).then(d => {
    if (d.ok) {
      document.getElementById('resume-btn').style.display = 'none';
      document.getElementById('pause-btn').style.display  = '';
      document.getElementById('last-poll').textContent = 'resumed…';
    }
  });
}

function uploadLogs() {
  const btn = document.getElementById('upload-btn');
  const status = document.getElementById('upload-status');
  btn.disabled = true;
  status.textContent = '⏳ uploading…';
  status.style.color = 'var(--muted)';
  fetch('/api/upload_logs', {method:'POST'})
  .then(r => r.json()).then(d => {
    btn.disabled = false;
    if (d.ok) {
      status.textContent = '✓ ' + (d.message || 'uploaded');
      status.style.color = 'var(--green)';
    } else {
      status.textContent = '✗ ' + (d.message || 'failed');
      status.style.color = 'var(--red)';
    }
    setTimeout(() => { status.textContent = ''; }, 8000);
  })
  .catch(e => {
    btn.disabled = false;
    status.textContent = '✗ ' + e;
    status.style.color = 'var(--red)';
    setTimeout(() => { status.textContent = ''; }, 8000);
  });
}

document.getElementById('mark-input').addEventListener('keydown', e => {
  if (e.key === 'Enter') markEvent();
  if (e.key === 'Escape') e.target.blur();
});

document.addEventListener('keydown', e => {
  if (e.key === 'm' && document.activeElement.tagName !== 'INPUT') {
    e.preventDefault();
    document.getElementById('mark-input').focus();
  }
});

// Initial load + polling
refreshFeed();
refreshState();
setInterval(refreshFeed,  3000);
setInterval(refreshState, 10000);
</script>
</body>
</html>
"""


class _Handler(BaseHTTPRequestHandler):
    """Minimal HTTP handler serving the dashboard and JSON API."""

    log_message = lambda *a: None  # silence access log

    def _send(self, code: int, ctype: str, body: bytes):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/" or path == "":
            self._send(200, "text/html; charset=utf-8",
                       DASHBOARD_HTML.encode("utf-8"))
        elif path == "/api/events":
            data = self.server.event_log.recent(200)
            self._send(200, "application/json",
                       json.dumps(data).encode("utf-8"))
        elif path == "/api/state":
            data = self.server.engine.state_summary()
            self._send(200, "application/json",
                       json.dumps(data).encode("utf-8"))
        else:
            self._send(404, "text/plain", b"Not found")

    def do_POST(self):
        path   = urlparse(self.path).path
        length = int(self.headers.get("Content-Length", 0))
        body   = json.loads(self.rfile.read(length) or b"{}") if length else {}

        if path == "/api/event":
            note = body.get("note", "").strip()
            if note:
                ev = make_event("USER_EVENT", "user", f"⚑  {note}")
                self.server.event_log.append(ev)
                logging.info(f"[USER_EVENT] {note}")
            self._send(200, "application/json", b'{"ok":true}')

        elif path == "/api/control":
            action = body.get("action", "")
            if action == "pause":
                self.server.engine.pause()
                self._send(200, "application/json", b'{"ok":true}')
            elif action == "resume":
                self.server.engine.resume()
                self._send(200, "application/json", b'{"ok":true}')
            else:
                self._send(400, "application/json", b'{"ok":false,"message":"unknown action"}')

        elif path == "/api/upload_logs":
            gh_cfg = self.server.github_cfg
            if not gh_cfg:
                self._send(200, "application/json",
                           json.dumps({"ok": False,
                                       "message": "github_config.json not found — cannot upload"
                                       }).encode())
                return
            log_path  = self.server.log_path
            site_name = self.server.site_name
            ok, msg = upload_log_to_github(log_path, site_name, gh_cfg)
            if ok:
                ev = make_event("log_uploaded", "info",
                                f"Log uploaded to GitHub: {msg}")
                self.server.event_log.append(ev)
            self._send(200, "application/json",
                       json.dumps({"ok": ok, "message": msg}).encode())

        else:
            self._send(404, "text/plain", b"Not found")


class DashboardServer:
    def __init__(self, port: int, log: EventLog, engine: WatchdogEngine,
                 log_path: str = "", site_name: str = "",
                 github_cfg: Optional[dict] = None):
        self._port   = port
        self._server = ThreadingHTTPServer(("0.0.0.0", port), _Handler)
        self._server.event_log  = log
        self._server.engine     = engine
        self._server.log_path   = log_path
        self._server.site_name  = site_name
        self._server.github_cfg = github_cfg

    def start(self):
        t = threading.Thread(target=self._server.serve_forever,
                             daemon=True, name="dashboard")
        t.start()
        logging.info(f"Dashboard: http://localhost:{self._port}")

    def stop(self):
        self._server.shutdown()


# ─────────────────────────────────────────────────────────────────────────────
# Config / switch loading
# ─────────────────────────────────────────────────────────────────────────────

def load_switches_for_site(config: dict, site_name: str,
                           output_dir: str) -> List[dict]:
    """
    Build a list of switch credential dicts to poll.

    Priority:
      1. static_hosts in site_config.yaml  (explicit known-good list)
      2. graph_state_<site>.json           (generated by discover.py)
      3. seed switch only                  (last resort)
    """
    sites    = config.get("sites", {})
    site_cfg = sites.get(site_name)
    if not site_cfg:
        logging.error(f"Site '{site_name}' not in config. Available: {list(sites.keys())}")
        sys.exit(1)

    seed = site_cfg.get("seed_switch", {})
    if not seed.get("ip"):
        logging.error("No seed switch IP configured.")
        sys.exit(1)

    base_creds = {k: seed[k] for k in
                  ("device_type","port","username","password","secret")
                  if k in seed}

    # Build skip-IP set from site config
    skip_ips = set(site_cfg.get("skip_ips", []))
    if skip_ips:
        logging.info(f"Skipping {len(skip_ips)} IPs listed in skip_ips: {sorted(skip_ips)}")

    # ── 1. static_hosts list (preferred — explicit, no mystery MAC devices) ──
    static_hosts = site_cfg.get("static_hosts", [])
    if static_hosts:
        switches = []
        for host in static_hosts:
            ip = host.get("ip")
            if not ip:
                continue
            if ip in skip_ips:
                logging.info(f"Skipping {host.get('hostname', ip)} ({ip}) — in skip_ips")
                continue
            sw = {
                **base_creds,
                "ip":       ip,
                "hostname": host.get("hostname", ip),
                "site":     site_name,
            }
            switches.append(sw)
        if switches:
            logging.info(f"Loaded {len(switches)} switch(es) from static_hosts in site_config")
            return switches

    # ── 2. graph_state JSON from a previous discovery run ────────────────────
    state_path = os.path.join(output_dir, f"graph_state_{site_name}.json")
    if os.path.exists(state_path):
        try:
            with open(state_path, encoding="utf-8") as f:
                state = json.load(f)
            switches = []
            for node in state.get("nodes", []):
                ip   = node["ip"]
                info = node.get("info", {})
                hostname = info.get("hostname", ip)
                # Skip nodes that only have a MAC address as hostname
                # (these are CDP-discovered non-SSH devices, not real switches)
                if re.match(r'^[0-9a-f]{12}$', hostname, re.I):
                    logging.info(f"Skipping MAC-only node {hostname} ({ip}) — not a named switch")
                    continue
                sw = {**base_creds, "ip": ip, "hostname": hostname, "site": site_name}
                switches.append(sw)
            if switches:
                logging.info(f"Loaded {len(switches)} switch(es) from {state_path}")
                return switches
        except Exception as e:
            logging.warning(f"Could not load graph state: {e}")

    # ── 3. Seed only ──────────────────────────────────────────────────────────
    logging.info(f"No switch list found — watching seed switch only ({seed['ip']})")
    return [{**base_creds, **seed, "site": site_name}]


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="NLC Network Watchdog – real-time Cisco switch monitoring",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python watch.py --site CWY
  python watch.py --site CWY --interval 15 --vlan 60
  python watch.py --event "Dante dropout stage left"   # mark incident
        """,
    )
    parser.add_argument("--config",   default="site_config.yaml")
    parser.add_argument("--site",     default=None,
                        help="Site name from config (e.g. CWY)")
    parser.add_argument("--interval", type=int, default=DEFAULT_INTERVAL,
                        help=f"Poll interval in seconds (default {DEFAULT_INTERVAL})")
    parser.add_argument("--port",     type=int, default=DEFAULT_PORT,
                        help=f"Dashboard HTTP port (default {DEFAULT_PORT})")
    parser.add_argument("--vlan",     default=DEFAULT_VLAN,
                        help=f"Dante/focus VLAN for IGMP reporting (default {DEFAULT_VLAN})")
    parser.add_argument("--event",    default=None,
                        help="Mark an incident in the running watchdog's log and exit")
    parser.add_argument("--verbose",  "-v", action="store_true")

    args = parser.parse_args()

    # ── --event mode: just POST to the running instance and exit ──────────
    if args.event:
        url  = f"http://localhost:{args.port}/api/event"
        body = json.dumps({"note": args.event}).encode("utf-8")
        try:
            req  = urllib.request.Request(url, data=body,
                                          headers={"Content-Type": "application/json"},
                                          method="POST")
            urllib.request.urlopen(req, timeout=5)
            print(f"✓  Event marked: {args.event}")
        except Exception as e:
            print(f"✗  Could not reach watchdog on port {args.port}: {e}")
            print("   Is watch.py running?  Start it first, then use --event to mark incidents.")
        sys.exit(0)

    # ── Normal watchdog mode ──────────────────────────────────────────────
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    if not args.site:
        parser.error("--site is required (e.g. --site CWY)")

    if not os.path.exists(args.config):
        print(f"ERROR: Config not found: {args.config}")
        sys.exit(1)

    with open(args.config, encoding="utf-8") as f:
        config = yaml.safe_load(f)

    output_dir = config.get("output", {}).get("directory", "./output")
    switches   = load_switches_for_site(config, args.site, output_dir)

    # Validate credentials
    for sw in switches:
        if not sw.get("username") or str(sw.get("username","")).startswith("YOUR_"):
            logging.error(f"Credentials not configured for {sw.get('ip')} — edit site_config.yaml")
            sys.exit(1)

    # Event log
    ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = os.path.join(output_dir, f"watchdog_{args.site}_{ts}.jsonl")
    evlog    = EventLog(log_path)

    # Pollers
    pollers = [SwitchPoller(sw, watch_vlan=args.vlan) for sw in switches]

    # GitHub config (optional — enables Send Logs button)
    github_cfg = load_github_config()
    if github_cfg:
        logging.info(f"GitHub upload enabled → elevateav/{WATCHDOG_LOG_REPO}")
    else:
        logging.info("No github_config.json found — Send Logs button will be disabled")

    # Engine + dashboard
    engine    = WatchdogEngine(pollers, evlog, args.interval)
    dashboard = DashboardServer(args.port, evlog, engine,
                                log_path=log_path, site_name=args.site,
                                github_cfg=github_cfg)

    print(f"\n{'='*60}")
    print(f"  NLC Network Watchdog  v{VERSION}")
    print(f"  Site:     {args.site}")
    print(f"  Switches: {len(pollers)}")
    print(f"  Interval: {args.interval}s")
    print(f"  VLAN:     {args.vlan}  (Dante focus)")
    print(f"  Log:      {log_path}")
    print(f"  Dashboard: http://localhost:{args.port}")
    print(f"{'='*60}")
    print()
    print("  Press  Ctrl+C  to stop.")
    print("  Mark an incident from another terminal:")
    print(f"    python watch.py --event \"Dante dropout\" --port {args.port}")
    print()

    dashboard.start()
    engine.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n  Stopping watchdog…")
        engine.stop()
        dashboard.stop()
        evlog.close()
        print(f"  Log saved: {log_path}")
        print("  Done.")


if __name__ == "__main__":
    main()
