@echo off
REM ============================================================
REM  NLC Network Watchdog - One-time installer
REM  Run this once on each management machine.
REM  Requires Python 3.9+ in PATH.
REM ============================================================

echo.
echo  NLC Network Watchdog - Installing dependencies...
echo  ============================================================

python --version 2>nul
if errorlevel 1 (
    echo  ERROR: Python not found in PATH.
    echo  Download from https://www.python.org/downloads/
    echo  Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)

echo.
echo  Installing Python packages...
pip install netmiko paramiko pyyaml --upgrade

if errorlevel 1 (
    echo.
    echo  ERROR: pip install failed. Try running as Administrator.
    pause
    exit /b 1
)

echo.
echo  ============================================================
echo  Installation complete!
echo.
echo  To start the watchdog:
echo    Double-click run_watchdog_CWY.bat
echo    OR run: python watch.py --site CWY
echo.
echo  Dashboard opens at: http://localhost:8080
echo  ============================================================
echo.
pause
