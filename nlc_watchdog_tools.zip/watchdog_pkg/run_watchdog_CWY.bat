@echo off
REM ============================================================
REM  NLC Network Watchdog - CWY Site
REM  Double-click to start monitoring all CWY switches.
REM  Dashboard: http://localhost:8080
REM ============================================================

cd /d "%~dp0"

echo.
echo  Starting NLC Network Watchdog for CWY...
echo  Dashboard will open at http://localhost:8080
echo.
echo  Press Ctrl+C in this window to stop.
echo.

start "" http://localhost:8080

python watch.py --site CWY --vlan 60

pause
