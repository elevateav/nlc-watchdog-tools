#!/usr/bin/env python3
"""
gitc.py  —  git wrapper for virtiofs / FUSE mounts where unlink() is blocked.

On virtiofs (the macOS ↔ Linux VM bridge used by Cowork/Claude Code),
git cannot delete its own lock files after each operation.  This means every
git command leaves behind stale .git/*.lock files, and the NEXT command
immediately fails with "cannot lock ref 'HEAD': File exists".

Fix: rename (not unlink) stale lock files out of the way before each git call.
os.rename() within the same FUSE mount works even when os.unlink() doesn't.

Usage (from sandbox Bash tool):
    python3 gitc.py add <files>
    python3 gitc.py commit -m "message"
    python3 gitc.py status
    python3 gitc.py log --oneline
    # …any git subcommand

The script is intentionally self-contained (stdlib only) so it works
in a clean Python environment without any pip installs.
"""
import glob
import os
import subprocess
import sys
import time


def _find_git_dir() -> str | None:
    """Walk up from cwd to find the nearest .git directory."""
    cwd = os.path.abspath(os.getcwd())
    for _ in range(15):
        candidate = os.path.join(cwd, ".git")
        if os.path.isdir(candidate):
            return candidate
        parent = os.path.dirname(cwd)
        if parent == cwd:
            break
        cwd = parent
    return None


def clear_stale_locks(git_dir: str) -> list[str]:
    """
    Rename all *.lock files in git_dir to *.lock.cleared.<timestamp>.
    Returns list of files that were cleared.
    """
    ts = int(time.time())
    cleared = []
    for lock in glob.glob(os.path.join(git_dir, "*.lock")):
        dest = f"{lock}.cleared.{ts}"
        try:
            os.rename(lock, dest)
            cleared.append(os.path.basename(lock))
        except OSError:
            pass   # shouldn't happen, but don't crash if it does
    return cleared


def main() -> int:
    git_dir = _find_git_dir()

    if git_dir:
        cleared = clear_stale_locks(git_dir)
        for name in cleared:
            print(f"[gitc] cleared stale lock: {name}", file=sys.stderr)

    result = subprocess.run(["git"] + sys.argv[1:])
    return result.returncode


if __name__ == "__main__":
    sys.exit(main())
